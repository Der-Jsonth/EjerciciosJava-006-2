-- Estas consultas pueden ejecutarse desde DB Browser for SQLite
-- (o usando sqlite3), sin modificar el Java.
SELECT * FROM libros ORDER BY id_libro;
SELECT * FROM socios ORDER BY id_socio;
SELECT * FROM prestamos ORDER BY id_prestamo;

SELECT p.id_prestamo, l.titulo, s.nombre, p.fecha_prestamo
FROM prestamos p
JOIN libros l ON p.id_libro = l.id_libro
JOIN socios s ON p.id_socio = s.id_socio
ORDER BY p.id_prestamo;
