-- Consultas de comprobación para ejecutar con un explorador SQLite.
SELECT * FROM libros ORDER BY id_libro;
SELECT * FROM socios ORDER BY id_socio;
SELECT * FROM prestamos ORDER BY id_prestamo;

-- Relaciones entre las 3 tablas: EJEMPLO de JOIN (comentado en clase).
SELECT p.id_prestamo, l.titulo, s.nombre, p.fecha_prestamo
FROM prestamos AS p
JOIN libros AS l ON l.id_libro = p.id_libro
JOIN socios AS s ON s.id_socio = p.id_socio
ORDER BY p.id_prestamo;
