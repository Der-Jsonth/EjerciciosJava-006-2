-- Script de referencia: ya se entrega el archivo data/biblioteca.db con estas tablas.
-- Para recrearlo, ejecutar en una base de datos SQLite nueva.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS libros (
    id_libro INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL CHECK (length(trim(titulo)) > 0),
    autor TEXT NOT NULL CHECK (length(trim(autor)) > 0)
);
CREATE TABLE IF NOT EXISTS socios (
    id_socio INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL CHECK (length(trim(nombre)) > 0),
    correo TEXT NOT NULL CHECK (length(trim(correo)) > 0)
);
CREATE TABLE IF NOT EXISTS prestamos (
    id_prestamo INTEGER PRIMARY KEY AUTOINCREMENT,
    id_libro INTEGER NOT NULL,
    id_socio INTEGER NOT NULL,
    fecha_prestamo TEXT NOT NULL,
    FOREIGN KEY (id_libro) REFERENCES libros(id_libro),
    FOREIGN KEY (id_socio) REFERENCES socios(id_socio)
);
