# Biblioteca LibroVivo — Experiencia de Aprendizaje 3 (ESTUDIANTES)

## Objetivo de la ayudantía (80 minutos)
Completar la conexión JDBC y las consultas SQL con `PreparedStatement` dentro de una aplicación JavaFX que **ya tiene las vistas, modales, modelos y repositorios creados**.

## Requisitos
- JDK 17 o superior y Maven (o Maven disponible desde IntelliJ IDEA).
- Dependencias Maven: `javafx-controls 21.0.2` y `sqlite-jdbc 3.46.1.3`.
- Abrir la carpeta del proyecto, la que contiene `pom.xml`, no una carpeta superior.

## Arranque
1. Descomprimir el ZIP en una carpeta con permisos de escritura.
2. En IntelliJ: abrir como proyecto Maven y esperar resolución de dependencias.
3. Ejecutar en la carpeta raíz: `mvn clean javafx:run`.
4. La interfaz puede abrir, pero los DAO marcados con TODO aún no funcionan. Es **normal**.

## Qué está hecho
- `MainApp.java`, `controller/BibliotecaController.java`: pestañas Libros/Socios/Préstamos, modales, controles y actualizaciones de `TableView`.
- `model/`: `Libro`, `Socio`, `Prestamo` como clases con getters, setters y `toString` apropiado.
- `repository/`: interfaces y método `listar` / `guardar`.
- `SocioDAO.listar()` y `PrestamoDAO.listar()` son ejemplos funcionales ya escritos.
- `data/biblioteca.db`: tabla `libros`, `socios`, `prestamos` con registros iniciales.
- `sql/`: creación de tablas y consultas para comprobar los datos.

## Qué debes implementar
1. `database/ConexionBD.java`: formar `jdbc:sqlite:<ruta absoluta>`, abrir conexión con `DriverManager.getConnection`, activar `PRAGMA foreign_keys = ON` y devolver la conexión.
2. `dao/LibroDAO.java`: `listar()` mediante `SELECT` + `PreparedStatement` + `ResultSet`; `guardar()` mediante `INSERT` + `setString` + `executeUpdate`.
3. `dao/SocioDAO.java`: completar `guardar()` (el `listar()` es ejemplo).
4. `dao/PrestamoDAO.java`: completar `guardar()` con dos IDs y fecha ISO `AAAA-MM-DD` (el `listar()` es ejemplo).

**Sustituye los textos `TODO` en las sentencias SQL por SQL válido y elimina las excepciones `PENDIENTE` cuando termines cada método.**

## Pruebas
- Botón **Probar conexión** → confirma la conexión.
- Botón **Actualizar tablas** → aparecen los datos iniciales.
- **Registrar libro**, **registrar socio** y **registrar préstamo** → los nuevos datos aparecen y siguen tras reiniciar.
- SQLite guarda datos en el archivo del proyecto `data/biblioteca.db` (relativo a la carpeta desde donde se ejecuta Maven).

## Alcance
Durante la ayudantía se trabajan `SELECT` e `INSERT`; `UPDATE` y `DELETE` son contenidos del semestre y quedan como extensión. No escribas SQL en el controlador JavaFX.
