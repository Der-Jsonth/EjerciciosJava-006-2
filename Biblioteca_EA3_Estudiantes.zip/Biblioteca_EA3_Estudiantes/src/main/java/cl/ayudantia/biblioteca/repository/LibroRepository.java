package cl.ayudantia.biblioteca.repository;
import cl.ayudantia.biblioteca.model.Libro;
public interface LibroRepository extends Repository<Libro> { }
