package cl.ayudantia.biblioteca.dao;

import cl.ayudantia.biblioteca.database.ConexionBD;
import cl.ayudantia.biblioteca.model.Libro;
import cl.ayudantia.biblioteca.repository.LibroRepository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** EA3: completar SELECT e INSERT mediante PreparedStatement. */
public class LibroDAO implements LibroRepository {
    @Override
    public List<Libro> listar() {
        String sql = "TODO: SELECT id_libro, titulo, autor FROM libros ORDER BY id_libro";
        List<Libro> libros = new ArrayList<>();
        try (Connection con = ConexionBD.obtener()) {
            // TODO: crear PreparedStatement; ejecutar executeQuery(); leer ResultSet.
            // TODO: con rs.next() construir Libro(id, titulo, autor) y añadir a libros.
            // TODO: retornar la lista. No escribir SQL en el controlador JavaFX.
            throw new UnsupportedOperationException("PENDIENTE EA3: LibroDAO.listar()");
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible listar libros", ex);
        }
    }

    @Override
    public void guardar(Libro libro) {
        String sql = "TODO: INSERT INTO libros (titulo, autor) VALUES (?, ?)";
        try (Connection con = ConexionBD.obtener()) {
            // TODO: PreparedStatement, setString(1,...), setString(2,...)
            // TODO: ejecutar executeUpdate() para guardar el registro.
            // El ID se genera automáticamente: NO se incorpora en el INSERT.
            throw new UnsupportedOperationException("PENDIENTE EA3: LibroDAO.guardar()");
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible guardar libro", ex);
        }
    }
}
