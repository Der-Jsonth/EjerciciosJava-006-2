package cl.ayudantia.biblioteca.repository;
import cl.ayudantia.biblioteca.model.Socio;
public interface SocioRepository extends Repository<Socio> { }
