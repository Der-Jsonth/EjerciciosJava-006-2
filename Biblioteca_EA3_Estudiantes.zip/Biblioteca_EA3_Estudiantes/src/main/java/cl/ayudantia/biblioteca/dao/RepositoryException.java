package cl.ayudantia.biblioteca.dao;
public class RepositoryException extends RuntimeException {
    public RepositoryException(String mensaje, Throwable causa) { super(mensaje, causa); }
}
