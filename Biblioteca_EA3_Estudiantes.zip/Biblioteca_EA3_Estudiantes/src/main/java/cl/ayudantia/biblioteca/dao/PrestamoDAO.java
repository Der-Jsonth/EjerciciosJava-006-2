package cl.ayudantia.biblioteca.dao;

import cl.ayudantia.biblioteca.database.ConexionBD;
import cl.ayudantia.biblioteca.model.Prestamo;
import cl.ayudantia.biblioteca.repository.PrestamoRepository;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDAO implements PrestamoRepository {
    @Override
    public List<Prestamo> listar() {
        String sql = "SELECT id_prestamo, id_libro, id_socio, fecha_prestamo "
                   + "FROM prestamos ORDER BY id_prestamo";
        List<Prestamo> resultado = new ArrayList<>();
        try (Connection con = ConexionBD.obtener();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                resultado.add(new Prestamo(rs.getInt("id_prestamo"),
                        rs.getInt("id_libro"), rs.getInt("id_socio"),
                        LocalDate.parse(rs.getString("fecha_prestamo"))));
            }
            return resultado;
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible listar los préstamos", ex);
        }
    }

    @Override
    public void guardar(Prestamo prestamo) {
        String sql = "TODO: INSERT INTO prestamos (id_libro, id_socio, fecha_prestamo) VALUES (?, ?, ?)";
        try (Connection con = ConexionBD.obtener()) {
            // TODO: usar con.prepareStatement(sql), asociar parámetros y executeUpdate().
            // Pista: getLibroId(), getSocioId() y getFecha().toString().
            throw new UnsupportedOperationException("PENDIENTE EA3: PrestamoDAO.guardar()");
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible registrar prestamo", ex);
        }
    }
}
