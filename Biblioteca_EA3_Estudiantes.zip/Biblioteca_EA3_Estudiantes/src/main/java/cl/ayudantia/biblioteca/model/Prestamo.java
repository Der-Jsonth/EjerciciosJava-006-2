package cl.ayudantia.biblioteca.model;

import java.time.LocalDate;

public class Prestamo {
    private int id;
    private int libroId;
    private int socioId;
    private LocalDate fecha;

    public Prestamo(int id, int libroId, int socioId, LocalDate fecha) {
        this.id = id;
        this.libroId = libroId;
        this.socioId = socioId;
        this.fecha = fecha;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getLibroId() { return libroId; }
    public void setLibroId(int libroId) { this.libroId = libroId; }
    public int getSocioId() { return socioId; }
    public void setSocioId(int socioId) { this.socioId = socioId; }
    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }
}
