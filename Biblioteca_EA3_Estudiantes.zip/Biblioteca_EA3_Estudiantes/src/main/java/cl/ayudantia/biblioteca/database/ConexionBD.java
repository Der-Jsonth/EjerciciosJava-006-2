package cl.ayudantia.biblioteca.database;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/** EA3: implementar JDBC para conectar la GUI JavaFX con SQLite. */
public final class ConexionBD {
    private ConexionBD() { }

    public static Connection obtener() throws SQLException {
        Path ruta = Path.of("data", "biblioteca.db").toAbsolutePath().normalize();
        if (!Files.isRegularFile(ruta)) {
            throw new SQLException("Archivo SQLite inexistente: " + ruta);
        }

        // TODO 1: crear String url comenzando con "jdbc:sqlite:" + ruta
        // TODO 2: DriverManager.getConnection(url) devuelve una Connection
        // TODO 3: con Statement ejecutar "PRAGMA foreign_keys = ON"
        // TODO 4: devolver la conexión abierta. Si PRAGMA falla, cerrarla.
        throw new SQLException("PENDIENTE EA3: implementar ConexionBD.obtener()");
    }
}
