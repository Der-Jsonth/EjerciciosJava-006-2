package cl.ayudantia.biblioteca.controller;

import cl.ayudantia.biblioteca.dao.*;
import cl.ayudantia.biblioteca.database.ConexionBD;
import cl.ayudantia.biblioteca.model.*;
import cl.ayudantia.biblioteca.repository.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.function.Function;

/** Interfaz y eventos listos. Los estudiantes implementan ConexionBD y los DAO pendientes. */
public class BibliotecaController {
    private final Stage ventana;
    private final LibroRepository libros = new LibroDAO();
    private final SocioRepository socios = new SocioDAO();
    private final PrestamoRepository prestamos = new PrestamoDAO();
    private final TableView<Libro> tablaLibros = new TableView<>();
    private final TableView<Socio> tablaSocios = new TableView<>();
    private final TableView<Prestamo> tablaPrestamos = new TableView<>();
    private final Label estado = new Label("Sin comprobar la conexión");

    public BibliotecaController(Stage ventana) { this.ventana = ventana; }

    public Parent crearVista() {
        Label titulo = new Label("Biblioteca LibroVivo");
        titulo.getStyleClass().add("main-title");
        Label subtitulo = new Label("Libros, socios y préstamos · SQLite / JDBC");
        subtitulo.getStyleClass().add("subtitle");
        VBox encabezado = new VBox(3, titulo, subtitulo);

        Button comprobar = new Button("Probar conexión");
        comprobar.getStyleClass().add("primary-button");
        comprobar.setOnAction(e -> probarConexion());
        Button actualizar = new Button("Actualizar tablas");
        actualizar.setOnAction(e -> actualizarTodo());
        estado.getStyleClass().add("status-label");
        HBox acciones = new HBox(10, comprobar, actualizar, estado);
        acciones.setAlignment(Pos.CENTER_LEFT);
        acciones.setPadding(new Insets(6, 0, 8, 0));

        configurarColumnas();
        TabPane tabs = new TabPane();
        tabs.getTabs().addAll(
                crearTab("Libros", tablaLibros, this::modalLibro),
                crearTab("Socios", tablaSocios, this::modalSocio),
                crearTab("Préstamos", tablaPrestamos, this::modalPrestamo));
        tabs.getTabs().forEach(t -> t.setClosable(false));

        Label pie = new Label("EA3: conexion JDBC, SELECT e INSERT mediante PreparedStatement");
        pie.getStyleClass().add("footer-label");
        VBox contenedor = new VBox(12, encabezado, acciones, tabs, pie);
        contenedor.setPadding(new Insets(22));
        VBox.setVgrow(tabs, Priority.ALWAYS);
        return contenedor;
    }

    private <T> Tab crearTab(String nombre, TableView<T> tabla, Runnable accion) {
        Button nuevo = new Button("+ Registrar " + nombre.toLowerCase());
        nuevo.getStyleClass().add("primary-button");
        nuevo.setOnAction(e -> accion.run());
        Label indicador = new Label("Los registros se guardan en data/biblioteca.db");
        indicador.getStyleClass().add("subtitle");
        HBox herramientas = new HBox(12, nuevo, indicador);
        herramientas.setAlignment(Pos.CENTER_LEFT);
        VBox panel = new VBox(12, herramientas, tabla);
        panel.setPadding(new Insets(16));
        VBox.setVgrow(tabla, Priority.ALWAYS);
        tabla.setPlaceholder(new Label("No hay registros cargados. Prueba la conexión."));
        return new Tab(nombre, panel);
    }

    private static <T> TableColumn<T, String> columna(String titulo, Function<T, String> valor) {
        TableColumn<T, String> columna = new TableColumn<>(titulo);
        columna.setCellValueFactory(fila -> new SimpleStringProperty(valor.apply(fila.getValue())));
        columna.setPrefWidth(200);
        return columna;
    }

    private void configurarColumnas() {
        tablaLibros.getColumns().addAll(
                columna("ID", l -> String.valueOf(l.getId())),
                columna("Título", Libro::getTitulo),
                columna("Autor", Libro::getAutor));
        tablaSocios.getColumns().addAll(
                columna("ID", s -> String.valueOf(s.getId())),
                columna("Nombre", Socio::getNombre),
                columna("Correo", Socio::getCorreo));
        tablaPrestamos.getColumns().addAll(
                columna("ID", p -> String.valueOf(p.getId())),
                columna("Libro", p -> nombreLibro(p.getLibroId())),
                columna("Socio", p -> nombreSocio(p.getSocioId())),
                columna("Fecha", p -> p.getFecha().toString()));
        tablaLibros.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tablaSocios.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tablaPrestamos.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    }

    private String nombreLibro(int id) {
        return tablaLibros.getItems().stream().filter(l -> l.getId() == id)
                .map(Libro::getTitulo).findFirst().orElse("Libro " + id);
    }

    private String nombreSocio(int id) {
        return tablaSocios.getItems().stream().filter(s -> s.getId() == id)
                .map(Socio::getNombre).findFirst().orElse("Socio " + id);
    }

    private void probarConexion() {
        try (Connection con = ConexionBD.obtener()) {
            if (!con.isValid(2)) throw new SQLException("La conexión no respondió.");
            estado.setText("Conexión SQLite correcta");
            actualizarTodo();
            mostrarInformacion("Conexión establecida", "La base de datos está disponible.");
        } catch (SQLException ex) {
            estado.setText("Sin conexión");
            mostrarError("No fue posible conectar a SQLite", ex);
        }
    }

    private void actualizarTodo() {
        try {
            var datosLibros = libros.listar();
            var datosSocios = socios.listar();
            var datosPrestamos = prestamos.listar();
            tablaLibros.setItems(FXCollections.observableArrayList(datosLibros));
            tablaSocios.setItems(FXCollections.observableArrayList(datosSocios));
            tablaPrestamos.setItems(FXCollections.observableArrayList(datosPrestamos));
            estado.setText("Datos cargados desde SQLite");
        } catch (RuntimeException ex) {
            estado.setText("Error de lectura");
            mostrarError("No se pudieron cargar las tablas", ex);
        }
    }

    private Dialog<ButtonType> dialogo(String titulo, GridPane formulario) {
        Dialog<ButtonType> dialogo = new Dialog<>();
        dialogo.initOwner(ventana);
        dialogo.initModality(Modality.WINDOW_MODAL);
        dialogo.setTitle(titulo);
        dialogo.getDialogPane().setContent(formulario);
        dialogo.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL, ButtonType.OK);
        return dialogo;
    }

    private GridPane formulario() {
        GridPane grilla = new GridPane();
        grilla.setPadding(new Insets(16));
        grilla.setHgap(10);
        grilla.setVgap(12);
        return grilla;
    }

    private void modalLibro() {
        TextField titulo = new TextField(); titulo.setPromptText("Título del libro");
        TextField autor = new TextField(); autor.setPromptText("Nombre del autor");
        GridPane g = formulario();
        g.addRow(0, new Label("Título"), titulo);
        g.addRow(1, new Label("Autor"), autor);
        var resultado = dialogo("Registrar libro", g).showAndWait();
        if (resultado.isEmpty() || resultado.get() != ButtonType.OK) return;
        if (titulo.getText().isBlank() || autor.getText().isBlank()) {
            mostrarInformacion("Datos incompletos", "Escribe un título y un autor.");
            return;
        }
        ejecutarGuardar(() -> libros.guardar(new Libro(0,
                titulo.getText().trim(), autor.getText().trim())));
    }

    private void modalSocio() {
        TextField nombre = new TextField(); nombre.setPromptText("Nombre completo");
        TextField correo = new TextField(); correo.setPromptText("correo@ejemplo.cl");
        GridPane g = formulario();
        g.addRow(0, new Label("Nombre"), nombre);
        g.addRow(1, new Label("Correo"), correo);
        var resultado = dialogo("Registrar socio", g).showAndWait();
        if (resultado.isEmpty() || resultado.get() != ButtonType.OK) return;
        if (nombre.getText().isBlank() || correo.getText().isBlank()) {
            mostrarInformacion("Datos incompletos", "Escribe un nombre y un correo.");
            return;
        }
        ejecutarGuardar(() -> socios.guardar(new Socio(0,
                nombre.getText().trim(), correo.getText().trim())));
    }

    private void modalPrestamo() {
        if (tablaLibros.getItems().isEmpty() || tablaSocios.getItems().isEmpty()) {
            mostrarInformacion("Faltan datos", "Primero registra al menos un libro y un socio.");
            return;
        }
        ComboBox<Libro> libro = new ComboBox<>(FXCollections.observableArrayList(tablaLibros.getItems()));
        ComboBox<Socio> socio = new ComboBox<>(FXCollections.observableArrayList(tablaSocios.getItems()));
        DatePicker fecha = new DatePicker(LocalDate.now());
        libro.setMaxWidth(Double.MAX_VALUE);
        socio.setMaxWidth(Double.MAX_VALUE);
        libro.getSelectionModel().selectFirst();
        socio.getSelectionModel().selectFirst();
        GridPane g = formulario();
        g.addRow(0, new Label("Libro"), libro);
        g.addRow(1, new Label("Socio"), socio);
        g.addRow(2, new Label("Fecha"), fecha);
        var resultado = dialogo("Registrar préstamo", g).showAndWait();
        if (resultado.isEmpty() || resultado.get() != ButtonType.OK) return;
        if (libro.getValue() == null || socio.getValue() == null || fecha.getValue() == null) {
            mostrarInformacion("Datos incompletos", "Selecciona un libro, un socio y una fecha.");
            return;
        }
        ejecutarGuardar(() -> prestamos.guardar(new Prestamo(0,
                libro.getValue().getId(), socio.getValue().getId(), fecha.getValue())));
    }

    private void ejecutarGuardar(Runnable guardar) {
        try {
            guardar.run();
            actualizarTodo();
        } catch (RuntimeException ex) {
            mostrarError("No se pudo registrar el dato", ex);
        }
    }

    private void mostrarInformacion(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, mensaje, ButtonType.OK);
        alert.initOwner(ventana);
        alert.setTitle(titulo);
        alert.setHeaderText(titulo);
        alert.showAndWait();
    }

    private void mostrarError(String titulo, Exception ex) {
        Throwable causa = ex.getCause() == null ? ex : ex.getCause();
        Alert alert = new Alert(Alert.AlertType.ERROR,
                titulo + "\n" + causa.getMessage(), ButtonType.OK);
        alert.initOwner(ventana);
        alert.setTitle(titulo);
        alert.setHeaderText("Revisa ConexionBD.java y data/biblioteca.db");
        alert.showAndWait();
    }
}
