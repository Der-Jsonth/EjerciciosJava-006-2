package cl.ayudantia.biblioteca;

import cl.ayudantia.biblioteca.controller.BibliotecaController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.net.URL;

public class MainApp extends Application {
    @Override
    public void start(Stage stage) {
        BibliotecaController controller = new BibliotecaController(stage);
        Scene escena = new Scene(controller.crearVista(), 940, 620);
        URL css = getClass().getResource("/css/app.css");
        if (css != null) escena.getStylesheets().add(css.toExternalForm());
        stage.setTitle("Biblioteca LibroVivo | JavaFX y SQLite");
        stage.setMinWidth(760);
        stage.setMinHeight(500);
        stage.setScene(escena);
        stage.show();
    }

    public static void main(String[] args) { launch(args); }
}
