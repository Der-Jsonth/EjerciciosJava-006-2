package cl.ayudantia.biblioteca.repository;
import java.util.List;
public interface Repository<T> {
    List<T> listar();
    void guardar(T objeto);
}
