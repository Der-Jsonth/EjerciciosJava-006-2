package cl.ayudantia.biblioteca.repository;
import cl.ayudantia.biblioteca.model.Prestamo;
public interface PrestamoRepository extends Repository<Prestamo> { }
