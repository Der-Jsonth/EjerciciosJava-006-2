package cl.ayudantia.biblioteca.dao;

import cl.ayudantia.biblioteca.database.ConexionBD;
import cl.ayudantia.biblioteca.model.Socio;
import cl.ayudantia.biblioteca.repository.SocioRepository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SocioDAO implements SocioRepository {
    @Override
    public List<Socio> listar() {
        String sql = "SELECT id_socio, nombre, correo FROM socios ORDER BY id_socio";
        List<Socio> resultado = new ArrayList<>();
        try (Connection con = ConexionBD.obtener();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                resultado.add(new Socio(rs.getInt("id_socio"),
                        rs.getString("nombre"), rs.getString("correo")));
            }
            return resultado;
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible listar los socios", ex);
        }
    }

    @Override
    public void guardar(Socio socio) {
        String sql = "TODO: INSERT INTO socios (nombre, correo) VALUES (?, ?)";
        try (Connection con = ConexionBD.obtener()) {
            // TODO: usar con.prepareStatement(sql), asociar parámetros y executeUpdate().
            // Pista: getNombre() y getCorreo() corresponden a setString.
            throw new UnsupportedOperationException("PENDIENTE EA3: SocioDAO.guardar()");
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible registrar socio", ex);
        }
    }
}
