package cl.ayudantia.biblioteca.database;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/** Clase final de conexión SQLite. Los DAO se encargan de cerrarla. */
public final class ConexionBD {
    private ConexionBD() { }

    public static Connection obtener() throws SQLException {
        Path ruta = Path.of("data", "biblioteca.db").toAbsolutePath().normalize();
        if (!Files.isRegularFile(ruta)) {
            throw new SQLException("No se encuentra la base SQLite en: " + ruta);
        }

        String url = "jdbc:sqlite:" + ruta;
        Connection conexion = DriverManager.getConnection(url);
        try (Statement statement = conexion.createStatement()) {
            statement.execute("PRAGMA foreign_keys = ON");
        } catch (SQLException ex) {
            conexion.close();
            throw ex;
        }
        return conexion;
    }
}
