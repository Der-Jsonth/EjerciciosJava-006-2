package cl.ayudantia.biblioteca.dao;

import cl.ayudantia.biblioteca.database.ConexionBD;
import cl.ayudantia.biblioteca.model.Libro;
import cl.ayudantia.biblioteca.repository.LibroRepository;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO implements LibroRepository {
    @Override
    public List<Libro> listar() {
        String sql = "SELECT id_libro, titulo, autor FROM libros ORDER BY id_libro";
        List<Libro> resultado = new ArrayList<>();
        try (Connection con = ConexionBD.obtener();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                resultado.add(new Libro(rs.getInt("id_libro"),
                        rs.getString("titulo"), rs.getString("autor")));
            }
            return resultado;
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible listar los libros", ex);
        }
    }

    @Override
    public void guardar(Libro libro) {
        String sql = "INSERT INTO libros (titulo, autor) VALUES (?, ?)";
        try (Connection con = ConexionBD.obtener();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new RepositoryException("No fue posible guardar el libro", ex);
        }
    }
}
