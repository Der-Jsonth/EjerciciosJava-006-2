# Biblioteca LibroVivo — Experiencia de Aprendizaje 3 (SOLUCIÓN DOCENTE)

Proyecto JavaFX completo con SQLite para apoyar una ayudantía de 80 minutos, y comparar el código de los estudiantes con la solución.

## Requisitos
- JDK 17 y Maven.
- Ejecución desde carpeta raíz: `mvn clean javafx:run`.
- El archivo `data/biblioteca.db` contiene tres tablas relacionadas y datos iniciales.

## Ruta didáctica
1. Explicar el flujo Vista JavaFX → Repository → DAO → JDBC → SQLite.
2. `ConexionBD`: URL, `DriverManager`, `Connection`, control de errores, `PRAGMA foreign_keys`.
3. `LibroDAO.listar`: `SELECT`, `PreparedStatement`, `executeQuery`, `ResultSet`.
4. `LibroDAO.guardar`: `INSERT`, `?`, `setString`, `executeUpdate`.
5. Replicar el patrón en `SocioDAO.guardar` y `PrestamoDAO.guardar` (`setInt`, `setString` para fecha).
6. Usar botón Probar conexión y Registrar; cerrar y abrir para verificar persistencia.

## Comparación con proyecto de estudiantes
La versión para estudiantes incluye todos los componentes de interfaz terminados, pero tiene **5 métodos pendientes**: `ConexionBD.obtener()`, `LibroDAO.listar()`, `LibroDAO.guardar()`, `SocioDAO.guardar()` y `PrestamoDAO.guardar()` (son cinco métodos contando conexión). Los `listar()` de Socio y Préstamo están completos y sirven de modelo.

## Nota técnica
No se implementan `UPDATE` ni `DELETE` (extensión). Se mantiene el acceso JDBC sin tareas asíncronas por claridad didáctica; en aplicaciones reales, preferir trabajo de BD fuera del hilo JavaFX.
